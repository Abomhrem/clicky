package com.clicky.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private const val DEFAULT_ACCEPT = "قبول,Accept,موافق"

    private fun p(c: Context) = c.getSharedPreferences("clicky", Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    fun minFare(c: Context) = p(c).getString("minFare", "2.0")?.toDoubleOrNull() ?: 2.0
    fun setMinFare(c: Context, v: String) = p(c).edit().putString("minFare", v).apply()
    fun maxMin(c: Context) = p(c).getInt("maxMin", 7)
    fun setMaxMin(c: Context, v: Int) = p(c).edit().putInt("maxMin", v).apply()
    fun maxKm(c: Context) = p(c).getString("maxKm", "50.0")?.toDoubleOrNull() ?: 50.0
    fun setMaxKm(c: Context, v: String) = p(c).edit().putString("maxKm", v).apply()
    fun acceptUnknown(c: Context) = p(c).getBoolean("acceptUnknown", false)
    fun setAcceptUnknown(c: Context, v: Boolean) = p(c).edit().putBoolean("acceptUnknown", v).apply()

    fun jeenyPkg(c: Context) = p(c).getString("jeenyPkg", "com.jeeny.driver")!!
    fun setJeenyPkg(c: Context, v: String) = p(c).edit().putString("jeenyPkg", v).apply()
    fun acceptTexts(c: Context) =
        (p(c).getString("acceptTexts", DEFAULT_ACCEPT) ?: DEFAULT_ACCEPT).split(",")

    fun serial(c: Context) = p(c).getString("serial", "") ?: ""
    fun expiry(c: Context) = p(c).getLong("expiry", 0L)
    fun setLicense(c: Context, s: String, exp: Long) =
        p(c).edit().putString("serial", s).putLong("expiry", exp).apply()
    fun lastValid(c: Context) = p(c).getBoolean("lastValid", false)
    fun setCheck(c: Context, ok: Boolean) = p(c).edit()
        .putBoolean("lastValid", ok).putLong("lastCheck", System.currentTimeMillis()).apply()

    // 24h grace: a temporary network failure must not kill acceptance mid-shift
    fun checkFresh(c: Context) =
        System.currentTimeMillis() - p(c).getLong("lastCheck", 0) < 24 * 60 * 60_000L

    fun debugText(c: Context) = p(c).getString("debug", "") ?: ""
    fun setDebugText(c: Context, v: String) =
        p(c).edit().putString("debug", v.take(4000)).apply()

    // Rolling decision log, newest first
    fun log(c: Context, line: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val old = p(c).getString("log", "") ?: ""
        p(c).edit().putString("log", "$stamp  $line\n$old".take(6000)).apply()
    }

    fun logText(c: Context) = p(c).getString("log", "") ?: ""
    fun clearLog(c: Context) = p(c).edit().putString("log", "").apply()

    // ---- Update channel (checked against Firebase RTDB "config" node) ----
    fun updLatest(c: Context) = p(c).getString("updLatest", "") ?: ""
    fun updUrl(c: Context) = p(c).getString("updUrl", "") ?: ""
    fun updForce(c: Context) = p(c).getBoolean("updForce", false)
    fun updSnoozeUntil(c: Context) = p(c).getLong("updSnooze", 0L)

    fun setUpdate(c: Context, latest: String, url: String, min: String) = p(c).edit()
        .putString("updLatest", latest)
        .putString("updUrl", url)
        .putBoolean("updForce",
            min.isNotEmpty() && UpdateManager.compare(min, UpdateManager.VERSION) > 0)
        .apply()

    fun snoozeUpdate(c: Context) = p(c).edit()
        .putLong("updSnooze", System.currentTimeMillis() + 4 * 60 * 60_000L).apply()
}
