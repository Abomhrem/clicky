package com.clicky.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object UpdateManager {
    const val VERSION = "1.1" // must match versionName in app/build.gradle

    fun check(ctx: Context) {
        Thread {
            val raw = try {
                val c = URL("${LicenseClient.BASE}/config.json").openConnection() as HttpURLConnection
                c.requestMethod = "GET"
                c.connectTimeout = 8000; c.readTimeout = 8000
                val s = if (c.responseCode < 400) c.inputStream else c.errorStream
                s?.bufferedReader()?.readText()
            } catch (e: Exception) { null } ?: return@Thread
            try {
                val o = JSONObject(raw)
                if (o.has("latestVersion")) {
                    Prefs.setUpdate(ctx,
                        o.optString("latestVersion", ""),
                        o.optString("apkUrl", ""),
                        o.optString("minVersion", ""))
                }
            } catch (_: Exception) { }
        }.start()
    }

    fun isNewer(serverVersion: String) = compare(serverVersion, VERSION) > 0

    fun compare(a: String, b: String): Int {
        val pa = a.trim().split(".").map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val pb = b.trim().split(".").map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(pa.size, pb.size)) {
            val d = pa.getOrElse(i) { 0 } - pb.getOrElse(i) { 0 }
            if (d != 0) return d
        }
        return 0
    }
}
