package com.clicky.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val MAX_NODES = 400
        private const val CLICK_COOLDOWN_MS = 2500L
        private const val SAME_REQUEST_WINDOW_MS = 45_000L
    }

    private var lastClick = 0L
    private var lastFingerprint = ""
    private var lastFingerprintAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var overlayRefresh: (() -> Unit)? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val checkLoop = object : Runnable {
        override fun run() {
            Thread { LicenseClient.isValid(this@AutoAcceptService) }.start()
            UpdateManager.check(this@AutoAcceptService)
            handler.postDelayed(this, 5 * 60_000L)
        }
    }

    private val overlayLoop = object : Runnable {
        override fun run() {
            overlayRefresh?.invoke()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Thread { LicenseClient.isValid(this) }.start()
        UpdateManager.check(this)
        handler.post(checkLoop)
        handler.post(overlayLoop)
        acquireWakeLock()
        showOverlay()
        Prefs.log(this, "الخدمة شغّالة ✅")
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clicky:service")
        try { wakeLock?.acquire(10 * 60 * 60 * 1000L) } catch (_: Exception) { }
    }

    private fun showOverlay() {
        val ctx = this
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val btn = Button(this).apply {
            fun refresh() {
                val on = Prefs.enabled(ctx)
                text = if (on) "✅ يعمل" else "⏸ موقوف"
                setBackgroundColor(if (on) 0xFF7B2FF2.toInt() else 0xFF444444.toInt())
                setTextColor(Color.WHITE)
            }
            refresh()
            overlayRefresh = { refresh() }
            setOnClickListener {
                Prefs.setEnabled(ctx, !Prefs.enabled(ctx))
                refresh()
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 250 }
        try { wm.addView(btn, params); overlay = btn } catch (_: Exception) { }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg != Prefs.jeenyPkg(this)) return
        if (!Prefs.enabled(this)) return
        if (!LicenseClient.cachedValid(this)) return

        val root = rootInActiveWindow ?: return
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        collect(root, nodes, sb, 0)
        Prefs.setDebugText(this, sb.toString())

        // 1) An accept-like button MUST exist in this window, else this is not a request screen
        val accept = nodes.firstOrNull { matchesAccept(it) } ?: return

        val text = sb.toString()
        val fare = Parsing.money(text)
        val mins = Parsing.minutes(text)
        val km = Parsing.km(text)
        val found = listOfNotNull(fare, mins, km).size

        val decision: String
        when {
            // A real request card shows at least 2 of: fare, time, distance.
            found < 2 && !Prefs.acceptUnknown(this) ->
                decision = "تجاهل: معلومات ناقصة ($found من 3)"

            fare != null && fare < Prefs.minFare(this) ->
                decision = "رفض: الأجرة $fare أقل من الحد ${Prefs.minFare(this)}"

            mins != null && mins > Prefs.maxMin(this) ->
                decision = "رفض: الزمن $mins دقيقة أكبر من الحد ${Prefs.maxMin(this)}"

            km != null && km > Prefs.maxKm(this) ->
                decision = "رفض: المسافة $km كم أكبر من الحد ${Prefs.maxKm(this)}"

            else -> {
                val fp = "$fare|$mins|$km"
                val now = System.currentTimeMillis()
                when {
                    fp == lastFingerprint && now - lastFingerprintAt < SAME_REQUEST_WINDOW_MS ->
                        decision = "تم قبول هذا الطلب مسبقاً"
                    now - lastClick < CLICK_COOLDOWN_MS ->
                        decision = "انتظار (منع النقر المتكرر)"
                    else -> {
                        lastFingerprint = fp
                        lastFingerprintAt = now
                        lastClick = now
                        var target: AccessibilityNodeInfo? = accept
                        while (target != null && !target.isClickable) target = target.parent
                        val clicked = target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                        decision = if (clicked)
                            "✅ قبِلنا الطلب ($fare دينار، $mins دقيقة، $km كم)"
                        else
                            "⚠️ فشل الضغط على زر القبول"
                    }
                }
            }
        }
        Prefs.log(this, decision)
    }

    private fun matchesAccept(n: AccessibilityNodeInfo): Boolean {
        val t = ((n.text?.toString() ?: "") + " " +
                (n.contentDescription?.toString() ?: "")).trim()
        if (t.isEmpty()) return false
        return Prefs.acceptTexts(this).any {
            it.isNotBlank() && t.contains(it.trim(), ignoreCase = true)
        }
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>,
                        sb: StringBuilder, depth: Int): Boolean {
        if (out.size >= MAX_NODES) return false
        out.add(n)
        n.text?.let { sb.append(it).append(" | ") }
        n.contentDescription?.let { sb.append(it).append(" | ") }
        if (depth < 30) {
            for (i in 0 until n.childCount) {
                val child = n.getChild(i) ?: continue
                if (!collect(child, out, sb, depth + 1)) return false
            }
        }
        return true
    }

    override fun onInterrupt() { }

    override fun onDestroy() {
        handler.removeCallbacks(checkLoop)
        handler.removeCallbacks(overlayLoop)
        try { wakeLock?.release() } catch (_: Exception) { }
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
            catch (_: Exception) { }
        }
        super.onDestroy()
    }
}
