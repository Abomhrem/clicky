package com.clicky.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var serial: EditText
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 64, 48, 48)
        }
        fun title(t: String, big: Boolean = false) = box.addView(TextView(ctx).apply {
            text = t; textSize = if (big) 24f else 16f; gravity = Gravity.CENTER
            setPadding(0, 24, 0, 16)
        })
        fun field(hint: String, init: String, numeric: Boolean = false): EditText =
            EditText(ctx).apply {
                setHint(hint); setText(init)
                if (numeric) inputType =
                    InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                box.addView(this)
            }
        fun button(label: String, color: Int, listener: View.OnClickListener) =
            box.addView(Button(ctx).apply {
                text = label; setBackgroundColor(color); setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener(listener)
            })
        fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

        title("Clicky", true)
        title("تفعيل التطبيق")
        serial = field("أدخل الرمز (مثال: CK-XXXX-XXXX-XXXX)", Prefs.serial(this))
        button("تفعيل", 0xFF7B2FF2.toInt()) {
            LicenseClient.activate(ctx, serial.text.toString()) { msg ->
                status.text = msg
                toast(msg)
            }
        }
        status = TextView(ctx).apply {
            gravity = Gravity.CENTER; setPadding(0, 8, 0, 24); box.addView(this)
        }
        button("فحص الترخيص الآن", 0xFF444444.toInt()) {
            Thread { LicenseClient.isValid(ctx) }.start()
            toast("جارٍ الفحص...")
        }
        button("فتح إعدادات إمكانية الوصول (خطوة إلزامية)", 0xFF2F80ED.toInt()) {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        title("إعدادات الفلترة — اختر حدودك")
        val minFare = field(
            "١) الحد الأدنى للأجرة (دينار أردني)",
            Prefs.minFare(ctx).toString(), numeric = true)
        val maxKm = field(
            "٢) أقصى مسافة لاستلام العميل (كم)",
            Prefs.maxKm(ctx).toString(), numeric = true)
        val maxMin = field(
            "٣) أقصى وقت للوصول إلى العميل (دقيقة)",
            Prefs.maxMin(ctx).toString(), numeric = true)
        val acceptUnknown = CheckBox(ctx).apply {
            text = "اقبل الطلبات التي لا يظهر فيها السعر أو الوقت أو المسافة (غير مُوصى به)"
            isChecked = Prefs.acceptUnknown(ctx)
            box.addView(this)
        }
        button("حفظ الإعدادات", 0xFF27AE60.toInt()) {
            val f = minFare.text.toString().trim().replace(',', '.').toDoubleOrNull()
            val k = maxKm.text.toString().trim().replace(',', '.').toDoubleOrNull()
            val m = maxMin.text.toString().trim().toIntOrNull()
            when {
                f == null || f < 0 -> toast("❌ الحد الأدنى للأجرة غير صحيح")
                k == null || k <= 0 -> toast("❌ المسافة القصوى غير صحيحة")
                m == null || m <= 0 -> toast("❌ الوقت الأقصى غير صحيح")
                else -> {
                    Prefs.setMinFare(ctx, f.toString())
                    Prefs.setMaxKm(ctx, k.toString())
                    Prefs.setMaxMin(ctx, m)
                    Prefs.setAcceptUnknown(ctx, acceptUnknown.isChecked)
                    toast("✅ تم الحفظ")
                }
            }
        }

        title("سجل القرارات (لماذا قبِل/رفض؟)")
        logView = TextView(ctx).apply {
            textSize = 12f
            setPadding(0, 8, 0, 16)
            box.addView(this)
        }
        button("مسح السجل", 0xFF444444.toInt()) {
            Prefs.clearLog(ctx)
            refreshLog()
        }
        button("عرض آخر نص تم التقاطه من Jeeny (للتشخيص)", 0xFF555555.toInt()) {
            AlertDialog.Builder(ctx).setTitle("Captured text")
                .setMessage(Prefs.debugText(ctx).ifEmpty { "لا شيء بعد — افتح Jeeny وانتظر طلباً" })
                .setPositiveButton("نسخ") { _, _ ->
                    val cm = getSystemService(CLIPBOARD_SERVICE)
                            as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(
                        "t", Prefs.debugText(ctx)))
                }
                .setNegativeButton("إغلاق", null).show()
        }

        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun refreshLog() {
        logView.text = Prefs.logText(this).ifEmpty { "لا يوجد بعد" }
    }

    override fun onResume() {
        super.onResume()
        val exp = Prefs.expiry(this)
        status.text = when {
            exp == 0L -> "غير مفعّل"
            System.currentTimeMillis() >= exp -> "⏰ منتهي الصلاحية"
            else -> "✅ مفعّل حتى: " +
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(exp))
        }
        refreshLog()
        UpdateManager.check(this)
        maybeShowUpdateDialog()
    }

    private fun maybeShowUpdateDialog() {
        val latest = Prefs.updLatest(this)
        if (latest.isEmpty() || !UpdateManager.isNewer(latest)) return
        val force = Prefs.updForce(this)
        if (!force && System.currentTimeMillis() < Prefs.updSnoozeUntil(this)) return
        val url = Prefs.updUrl(this)
        val dlg = AlertDialog.Builder(this)
            .setTitle("تحديث جديد متوفر 🔄")
            .setMessage(
                "الإصدار $latest متوفر الآن." +
                (if (force) "\n\nهذا التحديث إلزامي — لا يمكن المتابعة بدونه." else ""))
            .setPositiveButton("تحديث الآن") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                } catch (_: Exception) {
                    Toast.makeText(this, "تعذر فتح رابط التحميل", Toast.LENGTH_LONG).show()
                }
                if (force) finish()
            }
        if (!force) dlg.setNegativeButton("لاحقاً") { _, _ -> Prefs.snoozeUpdate(this) }
        dlg.setCancelable(!force).show()
    }
}
